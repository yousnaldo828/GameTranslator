package com.example.gametranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var appsSummary: TextView
    private lateinit var preview: TextView
    private lateinit var colorRow: LinearLayout

    private val colors = intArrayOf(
        0xFFFFFFFF.toInt(), // أبيض
        0xFFFFEB3B.toInt(), // أصفر
        0xFF69F0AE.toInt(), // أخضر
        0xFF40C4FF.toInt(), // سماوي
        0xFFFFAB40.toInt()  // برتقالي
    )

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // نكمل حتى لو رفض المستخدم الإشعارات
            prepareModelThenCapture()
        }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val intent = Intent(this, TranslateService::class.java).apply {
                    putExtra(TranslateService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(TranslateService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(
                    this,
                    "افتح اللعبة ثم اضغط على زر 🌐 لتحديد منطقة الحوار",
                    Toast.LENGTH_LONG
                ).show()
                moveTaskToBack(true)
            } else {
                setStatus("لم يتم منح إذن التقاط الشاشة.")
            }
            startButton.isEnabled = true
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        root.addView(TextView(this).apply {
            text = "مترجم الألعاب\nإنجليزي ← عربي"
            textSize = 24f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            text = "اضبط الإعدادات بالأسفل، ثم اضغط «ابدأ» وافتح اللعبة."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(status)

        startButton = Button(this).apply {
            text = "ابدأ"
            setOnClickListener { onStartClicked() }
        }
        root.addView(startButton)
        root.addView(Button(this).apply {
            text = "إيقاف الخدمة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TranslateService::class.java))
                setStatus("تم الإيقاف.")
            }
        })

        // ------------------------------------------------ التطبيقات
        root.addView(sectionTitle("التطبيقات"))
        appsSummary = TextView(this).apply { textSize = 15f }
        root.addView(appsSummary)
        root.addView(Button(this).apply {
            text = "اختيار التطبيقات"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, AppPickerActivity::class.java))
            }
        })

        // ------------------------------------------------ المظهر
        root.addView(sectionTitle("مظهر الترجمة"))

        addSlider(
            root, "حجم الخط", 12, 40, Prefs.fontSp(this),
            { "$it" }
        ) {
            Prefs.putInt(this, Prefs.KEY_FONT, it)
            updatePreview()
        }

        addSlider(
            root, "شفافية الخلفية (0 = شفاف تمامًا)", 0, 100, Prefs.bgOpacity(this),
            { "$it%" }
        ) {
            Prefs.putInt(this, Prefs.KEY_BG_OPACITY, it)
            updatePreview()
        }

        root.addView(TextView(this).apply {
            text = "لون الخط:"
            textSize = 15f
            setPadding(0, dp(12), 0, 0)
        })
        colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(colorRow)
        renderColors()

        root.addView(TextView(this).apply {
            text = "مكان ظهور الترجمة:"
            textSize = 15f
            setPadding(0, dp(12), 0, 0)
        })
        val positions = listOf(
            "فوق منطقة الحوار",
            "تحت منطقة الحوار",
            "أعلى الشاشة",
            "وسط الشاشة",
            "أسفل الشاشة"
        )
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        positions.forEachIndexed { i, name ->
            group.addView(RadioButton(this).apply {
                id = i + 1
                text = name
            })
        }
        group.check(Prefs.position(this) + 1)
        group.setOnCheckedChangeListener { _, checkedId ->
            // اختيار مكان جديد يلغي أي مكان حرّكت إليه الشريط بيدك
            Prefs.clearCustomBarPositions(this)
            Prefs.putInt(this, Prefs.KEY_POSITION, checkedId - 1)
        }
        root.addView(group)
        root.addView(TextView(this).apply {
            text = "يمكنك أيضًا تحريك الشريط أثناء اللعب: اضغط عليه مطولًا ثم اسحبه، ويُحفظ المكان لكل لعبة.\n" +
                "إذا تداخل المكان المختار مع منطقة الحوار، تنتقل الترجمة تلقائيًا فوقها أو تحتها."
            textSize = 12f
        })

        // ------------------------------------------------ مدة ظهور الجملة
        root.addView(sectionTitle("مدة ظهور الجملة"))
        addSlider(
            root, "كل جملة تبقى", Prefs.MIN_DURATION_MS / 500, Prefs.MAX_DURATION_MS / 500,
            Prefs.durationMs(this) / 500,
            { String.format("%.1f ثانية", it / 2.0) }
        ) {
            Prefs.putInt(this, Prefs.KEY_DURATION, it * 500)
        }
        root.addView(TextView(this).apply {
            text = "إذا ظهرت جملة جديدة قبل انتهاء المدة، تظهر تحت الجملة السابقة، وتبقى كل جملة حتى تكمل مدتها."
            textSize = 12f
        })

        // ------------------------------------------------ السرعة
        root.addView(sectionTitle("السرعة"))
        addSlider(
            root, "التحديث كل", Prefs.MIN_INTERVAL_MS / 100, Prefs.MAX_INTERVAL_MS / 100,
            Prefs.intervalMs(this) / 100,
            { String.format("%.1f ثانية", it / 10.0) }
        ) {
            Prefs.putInt(this, Prefs.KEY_INTERVAL, it * 100)
        }
        root.addView(TextView(this).apply {
            text = "أسرع قيمة هي 0.2 ثانية. السرعة الفعلية تعتمد أيضًا على قوة هاتفك."
            textSize = 12f
        })

        // ------------------------------------------------ المعاينة
        root.addView(sectionTitle("معاينة"))
        preview = TextView(this).apply {
            text = "هذه معاينة لشكل الترجمة"
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat() }
        }
        val previewBox = FrameLayout(this).apply {
            setBackgroundColor(0xFF607D8B.toInt())
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        previewBox.addView(
            preview,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(previewBox)
        updatePreview()

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val n = Prefs.apps(this).size
        appsSummary.text = if (n == 0) {
            "لم تختر تطبيقات: الترجمة ستعمل في كل التطبيقات."
        } else {
            "المختارة: $n تطبيق. الترجمة تظهر فيها فقط."
        }
    }

    // ------------------------------------------------------------ أدوات الواجهة

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 18f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        min: Int,
        max: Int,
        value: Int,
        format: (Int) -> String,
        onChange: (Int) -> Unit
    ) {
        val label = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(12), 0, 0)
            text = "$title: ${format(value)}"
        }
        val seek = SeekBar(this)
        seek.max = max - min
        seek.progress = (value - min).coerceIn(0, max - min)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                label.text = "$title: ${format(v)}"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        parent.addView(label)
        parent.addView(seek)
    }

    private fun renderColors() {
        colorRow.removeAllViews()
        val current = Prefs.textColor(this)
        for (c in colors) {
            val selected = c == current
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(
                        if (selected) dp(4) else dp(1),
                        if (selected) 0xFF1565C0.toInt() else Color.GRAY
                    )
                }
                setOnClickListener {
                    Prefs.putInt(this@MainActivity, Prefs.KEY_TEXT_COLOR, c)
                    renderColors()
                    updatePreview()
                }
            }
            colorRow.addView(
                dot,
                LinearLayout.LayoutParams(dp(44), dp(44)).apply {
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                }
            )
        }
    }

    private fun updatePreview() {
        preview.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.fontSp(this).toFloat())
        preview.setTextColor(Prefs.textColor(this))
        preview.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        (preview.background as GradientDrawable)
            .setColor(Color.argb(Prefs.bgOpacity(this) * 255 / 100, 0, 0, 0))
    }

    // ------------------------------------------------------------ التشغيل

    private fun onStartClicked() {
        // 1) إذن الرسم فوق التطبيقات
        if (!Settings.canDrawOverlays(this)) {
            setStatus("فعّل إذن «العرض فوق التطبيقات الأخرى» ثم ارجع واضغط «ابدأ» مرة أخرى.")
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        // 2) إذن معرفة التطبيق المفتوح (فقط إذا اخترت تطبيقات محددة)
        if (Prefs.apps(this).isNotEmpty() && !Prefs.hasUsageAccess(this)) {
            setStatus(
                "لمعرفة التطبيق المفتوح، فعّل الإذن لهذا التطبيق في «الوصول إلى بيانات الاستخدام» " +
                    "ثم ارجع واضغط «ابدأ» مرة أخرى."
            )
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        // 3) إذن الإشعارات (أندرويد 13+)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        prepareModelThenCapture()
    }

    private fun prepareModelThenCapture() {
        startButton.isEnabled = false
        setStatus("جارٍ تحميل نموذج الترجمة (مرة واحدة فقط، يحتاج إنترنت)...")
        lifecycleScope.launch {
            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build()
            )
            try {
                translator.downloadModelIfNeeded().await()
                setStatus("النموذج جاهز. وافق على التقاط الشاشة.")
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                captureLauncher.launch(mpm.createScreenCaptureIntent())
            } catch (e: Exception) {
                setStatus("فشل تحميل النموذج. تأكد من الاتصال بالإنترنت وحاول مجددًا.")
                startButton.isEnabled = true
            } finally {
                translator.close()
            }
        }
    }

    private fun setStatus(text: String) {
        status.text = text
    }
}
