package com.example.gametranslator

import android.app.AppOpsManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Process

/** كل إعدادات التطبيق في مكان واحد. */
object Prefs {
    const val KEY_APPS = "apps"
    const val KEY_FONT = "font_sp"
    const val KEY_BG_OPACITY = "bg_opacity"
    const val KEY_TEXT_COLOR = "text_color"
    const val KEY_POSITION = "position"
    const val KEY_INTERVAL = "interval_ms"
    const val KEY_DURATION = "duration_ms"

    // أماكن ظهور الترجمة
    const val POS_ABOVE = 0   // فوق منطقة الحوار
    const val POS_BELOW = 1   // تحت منطقة الحوار
    const val POS_TOP = 2     // أعلى الشاشة
    const val POS_MIDDLE = 3  // وسط الشاشة
    const val POS_BOTTOM = 4  // أسفل الشاشة

    const val MIN_INTERVAL_MS = 200
    const val MAX_INTERVAL_MS = 2000

    const val MIN_DURATION_MS = 1000
    const val MAX_DURATION_MS = 15000

    fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun apps(c: Context): Set<String> =
        HashSet(sp(c).getStringSet(KEY_APPS, emptySet()) ?: emptySet())

    fun setApps(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet(KEY_APPS, HashSet(v)).apply()
    }

    fun fontSp(c: Context): Int = sp(c).getInt(KEY_FONT, 20)
    fun bgOpacity(c: Context): Int = sp(c).getInt(KEY_BG_OPACITY, 85) // نسبة مئوية 0..100
    fun textColor(c: Context): Int = sp(c).getInt(KEY_TEXT_COLOR, 0xFFFFFFFF.toInt())
    fun position(c: Context): Int = sp(c).getInt(KEY_POSITION, POS_ABOVE)
    fun intervalMs(c: Context): Int =
        sp(c).getInt(KEY_INTERVAL, MIN_INTERVAL_MS).coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)

    /** مدة بقاء كل جملة مترجمة على الشاشة. */
    fun durationMs(c: Context): Int =
        sp(c).getInt(KEY_DURATION, 4000).coerceIn(MIN_DURATION_MS, MAX_DURATION_MS)

    fun putInt(c: Context, key: String, v: Int) {
        sp(c).edit().putInt(key, v).apply()
    }

    /** يمسح الأماكن التي حرّك إليها المستخدم الشريط بيده (فيعود لمكان الإعداد المختار). */
    fun clearCustomBarPositions(c: Context) {
        val prefs = sp(c)
        val editor = prefs.edit()
        for (key in prefs.all.keys) {
            if (key.startsWith("barpos_")) editor.remove(key)
        }
        editor.apply()
    }

    /** هل منح المستخدم إذن «الوصول إلى بيانات الاستخدام» (لمعرفة التطبيق المفتوح)؟ */
    @Suppress("DEPRECATION")
    fun hasUsageAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
            )
        } else {
            ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
