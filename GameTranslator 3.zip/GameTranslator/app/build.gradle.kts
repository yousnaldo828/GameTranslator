plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---- خيارات اختيارية عند البناء من سطر الأوامر ----
//   gradle assembleDebug                      -> APK واحد يدعم arm64 و armeabi-v7a (معظم الهواتف)
//   gradle assembleDebug -Pabi=arm64-v8a      -> APK أصغر لمعمارية واحدة فقط
//   gradle assembleDebug -PsplitAbi=true      -> APK منفصل لكل معمارية
val abiList: List<String> = (project.findProperty("abi") as String?)
    ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
    ?: listOf("arm64-v8a", "armeabi-v7a")
val splitAbi: Boolean = project.hasProperty("splitAbi")

android {
    namespace = "com.example.gametranslator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.gametranslator"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"

        // نحذف مكتبات x86 و x86_64 (للمحاكيات فقط) لتقليل الحجم إلى النصف تقريبًا
        if (!splitAbi) {
            ndk {
                abiFilters += abiList
            }
        }
        // لغات الواجهة المطلوبة فقط
        resourceConfigurations += listOf("ar", "en")
    }

    if (splitAbi) {
        splits {
            abi {
                isEnable = true
                reset()
                include("arm64-v8a", "armeabi-v7a")
                isUniversalApk = false
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // Coroutines (+ await() for Google Tasks)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // ML Kit: OCR (Latin script, bundled in the app) + offline translation
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.mlkit:translate:17.0.3")
}
