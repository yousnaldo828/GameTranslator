package com.example.gametranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.LruCache
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * الخدمة الأمامية التي تقوم بالعمل كله:
 * التقاط الشاشة -> قص منطقة الحوار -> (تخطي إن لم تتغير) -> OCR -> انتظار استقرار النص -> ترجمة -> عرض.
 * وتعمل فقط داخل التطبيقات التي اختارها المستخدم (أو في الكل إن لم يختر شيئًا).
 */
class TranslateService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val ACTION_STOP = "com.example.gametranslator.STOP"
        private const val CHANNEL_ID = "translator"
        private const val NOTIF_ID = 1
        private const val WATCH_DELAY_MS = 700L
        private const val MAX_CAPTIONS = 5
        private const val MAX_UNSTABLE_READS = 8
        private const val CACHE_SIZE = 300
        private const val IDLE_SCANS_BEFORE_BACKOFF = 5
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var pm: PowerManager

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    // أبعاد الشاشة الحقيقية (تُستخدم لإحداثيات النوافذ العائمة)
    @Volatile private var capW = 0
    @Volatile private var capH = 0

    // أبعاد الصورة الملتقطة فعليًا (قد تكون أصغر حسب «جودة المعالجة»)
    @Volatile private var imgW = 0

    @Volatile private var region: Rect? = null
    private var selectionView: SelectionView? = null
    private var bubble: TextView? = null
    private var bar: LinearLayout? = null // حاوية الترجمات (جمل متراكمة)
    private val captions = ArrayList<TextView>()
    private var loopJob: Job? = null
    private var watcherJob: Job? = null

    // يُزاد عند الحاجة لتصفير حالة القراءة؛ حلقة القراءة تلاحظه وتصفّر متغيراتها المحلية
    @Volatile private var textGen = 0

    private val cache = LruCache<String, String>(CACHE_SIZE)
    private var translationErrors = 0
    private val spaces = Regex("\\s+")
    private var hashRow = IntArray(0)

    // مراقبة التطبيق المفتوح
    @Volatile private var allowed = true
    @Volatile private var contextPkg: String? = null
    private var lastForeground: String? = null
    private var lastEventTs = 0L

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )

    // يجب الاحتفاظ بمرجع قوي للمستمع وإلا يُحذف تلقائيًا
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when {
            key == Prefs.KEY_CACHE_CLEAR -> cache.evictAll()
            key == Prefs.KEY_SCALE -> main.post {
                try {
                    rebuildCapture()
                    resetTextState()
                } catch (_: Exception) { }
            }
            key != null && (key.startsWith("region_") || key.startsWith("barpos_")) -> { }
            else -> main.post { restyleBar() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY // الخدمة تعمل بالفعل

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        startAsForeground()

        // إذن العرض فوق التطبيقات قد يُسحب بين الضغط على «ابدأ» وهنا
        if (!Settings.canDrawOverlays(this)) {
            toast("إذن العرض فوق التطبيقات غير مفعّل")
            stopSelf()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = try {
            mpm.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            null
        }
        if (projection == null) {
            toast("تعذّر بدء التقاط الشاشة")
            stopSelf()
            return START_NOT_STICKY
        }
        // أندرويد 14 يشترط تسجيل callback قبل إنشاء VirtualDisplay
        val cb = object : MediaProjection.Callback() {
            override fun onStop() {
                toast("توقف التقاط الشاشة")
                stopSelf()
            }
        }
        projectionCallback = cb
        projection?.registerCallback(cb, main)

        try {
            rebuildCapture()
        } catch (e: Exception) {
            toast("تعذّر إنشاء قارئ الشاشة")
            stopSelf()
            return START_NOT_STICKY
        }
        showBubble()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefsListener)

        // تحميل النموذج (يكون جاهزًا غالبًا من الشاشة الرئيسية)
        scope.launch {
            try {
                translator.downloadModelIfNeeded().await()
            } catch (e: Exception) {
                toast("تعذّر تحميل نموذج الترجمة. تأكد من الإنترنت وأعد المحاولة.")
            }
        }
        startWatcher()
        startLoop()
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- إشعار

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "مترجم الألعاب", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification = builder
            .setContentTitle("مترجم الألعاب يعمل (الشاشة قيد الالتقاط)")
            .setContentText("اضغط على زر 🌐 فوق اللعبة لتحديد منطقة الحوار")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(Notification.Action.Builder(null, "إيقاف", stopIntent).build())
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    // ---------------------------------------------------------- التقاط الشاشة

    private fun screenSize(): Triple<Int, Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.configuration.densityDpi)
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }
    }

    /**
     * ينشئ (أو يعيد ضبط) قارئ الصور ليطابق اتجاه الشاشة الحالي وجودة المعالجة المختارة.
     * تقليل الدقة يخفض استهلاك الذاكرة والمعالج.
     */
    private fun rebuildCapture() {
        val (sw, sh, dpi) = screenSize()
        val scale = Prefs.scalePercent(this) / 100f
        val w = maxOf(16, (sw * scale).toInt())
        val h = maxOf(16, (sh * scale).toInt())

        val old = imageReader
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = virtualDisplay
        if (vd == null) {
            virtualDisplay = projection?.createVirtualDisplay(
                "GameTranslatorCapture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = reader.surface
        }
        imageReader = reader
        old?.close()
        capW = sw
        capH = sh
        imgW = w
    }

    /**
     * يلتقط آخر إطار ويعيد المنطقة المحددة فقط كصورة.
     * يُنسخ من الذاكرة الصفوف المطلوبة فقط (وليس الشاشة كلها) لتقليل استهلاك RAM.
     */
    private fun grabCrop(r: Rect): Bitmap? {
        val image = imageReader?.acquireLatestImage() ?: return null
        try {
            val factor = image.width.toFloat() / maxOf(1, capW)
            val x = (r.left * factor).toInt().coerceIn(0, image.width - 2)
            val y = (r.top * factor).toInt().coerceIn(0, maxOf(0, image.height - 3))
            val w = (r.width() * factor).toInt().coerceIn(1, image.width - x)
            // نترك صفًا واحدًا أخيرًا لأن آخر صف في الذاكرة قد لا يتضمن الحشو (padding)
            val h = minOf((r.height() * factor).toInt().coerceAtLeast(1), image.height - y - 1)
                .coerceAtLeast(1)

            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val buffer = plane.buffer
            buffer.position(y * rowStride)

            val wide = Bitmap.createBitmap(rowStride / pixelStride, h, Bitmap.Config.ARGB_8888)
            wide.copyPixelsFromBuffer(buffer)
            val crop = Bitmap.createBitmap(wide, x, 0, w, h)
            if (crop !== wide) wide.recycle()
            return crop
        } finally {
            image.close()
        }
    }

    /** بصمة سريعة للصورة: إن لم تتغير فلا داعي لتشغيل OCR مرة أخرى. */
    private fun quickHash(b: Bitmap): Long {
        if (hashRow.size < b.width) hashRow = IntArray(b.width)
        var hash = 1125899906842597L
        var y = 0
        while (y < b.height) {
            b.getPixels(hashRow, 0, b.width, 0, y, b.width, 1)
            var x = 0
            while (x < b.width) {
                hash = 31 * hash + hashRow[x]
                x += 3
            }
            y += 3
        }
        return hash
    }

    // ------------------------------------------- مراقبة التطبيق المفتوح حاليًا

    private fun updateForeground() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastEventTs == 0L) now - 2 * 3600 * 1000L else lastEventTs
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            lastEventTs = maxOf(lastEventTs, e.timeStamp + 1)
            val pkg = e.packageName ?: continue
            if (pkg == "com.android.systemui") continue
            @Suppress("DEPRECATION")
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> lastForeground = pkg
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (lastForeground == pkg) lastForeground = null
            }
        }
    }

    private fun startWatcher() {
        watcherJob = scope.launch {
            while (isActive) {
                val selected = Prefs.apps(this@TranslateService)
                val usage = Prefs.hasUsageAccess(this@TranslateService)
                if (usage) {
                    try { updateForeground() } catch (_: Exception) { }
                }
                val pkgNow = if (usage) lastForeground else null
                val newAllowed = selected.isEmpty() || !usage ||
                    (pkgNow != null && pkgNow in selected)

                if (newAllowed != allowed || pkgNow != contextPkg) {
                    allowed = newAllowed
                    contextPkg = pkgNow
                    withContext(Dispatchers.Main) { onContextChanged() }
                }
                delay(WATCH_DELAY_MS)
            }
        }
    }

    /** يطلب من حلقة القراءة تصفير حالتها (آمن من أي خيط). */
    private fun resetTextState() {
        textGen++
    }

    /** يُستدعى (في الخيط الرئيسي) عند تغيّر التطبيق المفتوح أو السماح بالعمل. */
    private fun onContextChanged() {
        resetTextState()
        captions.clear()
        removeView(bar); bar = null
        if (!allowed) {
            removeView(selectionView); selectionView = null
            bubble?.visibility = View.GONE
            region = null
            return
        }
        bubble?.visibility = View.VISIBLE
        region = loadRegion()
        region?.let { showBar(it) }
    }

    // ------------------------------------------- حفظ منطقة الحوار ومكان الشريط

    private fun regionKey() = "region_${contextPkg ?: "global"}_${capW}x$capH"
    private fun barPosKey() = "barpos_${contextPkg ?: "global"}_${capW}x$capH"

    private fun saveRegion(r: Rect) {
        Prefs.sp(this).edit()
            .putString(regionKey(), "${r.left},${r.top},${r.right},${r.bottom}")
            .apply()
    }

    private fun loadRegion(): Rect? {
        val s = Prefs.sp(this).getString(regionKey(), null) ?: return null
        val p = s.split(",")
        if (p.size != 4) return null
        return try {
            Rect(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt())
        } catch (e: NumberFormatException) {
            null
        }
    }

    private fun saveBarPos(x: Int, y: Int) {
        Prefs.sp(this).edit().putString(barPosKey(), "$x,$y").apply()
    }

    private fun loadBarPos(): Pair<Int, Int>? {
        val s = Prefs.sp(this).getString(barPosKey(), null) ?: return null
        val p = s.split(",")
        if (p.size != 2) return null
        return try {
            Pair(p[0].toInt(), p[1].toInt())
        } catch (e: NumberFormatException) {
            null
        }
    }

    // ---------------------------------------------------------- حلقة الترجمة

    /** يبقي الأسطر التي تحتوي على حروف فعلًا، ويتجاهل رموزًا وزخارف قرأها OCR خطأً. */
    private fun isTextual(line: String): Boolean {
        val visible = line.count { !it.isWhitespace() }
        if (visible < 2) return false
        return line.count { it.isLetter() } * 2 >= visible
    }

    private suspend fun recognize(crop: Bitmap): String {
        return try {
            val result = recognizer.process(InputImage.fromBitmap(crop, 0)).await()
            result.textBlocks
                .flatMap { it.lines }
                .map { it.text }
                .filter { isTextual(it) }
                .joinToString(" ")
                .replace(spaces, " ")
                .trim()
        } catch (e: Exception) {
            ""
        }
    }

    /** يترجم (مع ذاكرة مؤقتة) ثم يعرض الجملة. يعيد false عند الفشل ليُعاد المحاولة لاحقًا. */
    private suspend fun translateAndShow(text: String): Boolean {
        val translated = cache.get(text) ?: try {
            translator.translate(text).await().also { cache.put(text, it) }
        } catch (e: Exception) {
            translationErrors++
            if (translationErrors % 10 == 1) {
                toast("تعذّرت الترجمة. تأكد من تحميل النموذج (يحتاج إنترنت أول مرة).")
            }
            return false
        }
        withContext(Dispatchers.Main) { addCaption(translated, text) }
        return true
    }

    private fun startLoop() {
        loopJob = scope.launch {
            // كل حالة القراءة محلية داخل هذه الحلقة (لا تُشارَك مع خيوط أخرى)
            var pendingNorm = ""
            var pendingText = ""
            var shownNorm = ""
            var unstable = 0
            var empty = 0
            var lastHash = 0L
            var idle = 0
            var gen = textGen

            while (isActive) {
                // فحص متكيّف: إذا لم يتغير شيء لعدة مرات نُبطئ الفحص قليلًا لتوفير البطارية
                val base = Prefs.intervalMs(this@TranslateService).toLong()
                delay(if (idle >= IDLE_SCANS_BEFORE_BACKOFF) minOf(base * 2, maxOf(base, 1000L)) else base)

                if (!allowed) continue
                if (!pm.isInteractive) { // الشاشة مطفأة: لا حاجة للمعالجة
                    delay(1000)
                    continue
                }

                if (gen != textGen) {
                    gen = textGen
                    pendingNorm = ""; pendingText = ""; shownNorm = ""
                    unstable = 0; empty = 0; lastHash = 0L; idle = 0
                }

                // تغيّر اتجاه الشاشة: أعد الضبط، وإن لم توجد منطقة محفوظة اطلب تحديدًا جديدًا
                val (w, h, _) = screenSize()
                if (w != capW || h != capH) {
                    withContext(Dispatchers.Main) {
                        try { rebuildCapture() } catch (_: Exception) { }
                        onContextChanged()
                        if (allowed && region == null) showSelection()
                    }
                    continue
                }

                val r = region ?: continue
                val crop = (try { grabCrop(r) } catch (e: Exception) { null }) ?: continue

                // منع معالجة الصور المتطابقة
                val hash = quickHash(crop)
                if (hash == lastHash) {
                    crop.recycle()
                    idle++
                    if (empty >= 1) {
                        // اختفى الحوار وبقيت الصورة ثابتة
                        pendingNorm = ""; pendingText = ""; shownNorm = ""; unstable = 0
                    } else if (pendingNorm.isNotEmpty() && pendingNorm != shownNorm) {
                        // الصورة لم تتغير منذ آخر قراءة، فالنص مستقر: ترجمه الآن
                        if (translateAndShow(pendingText)) shownNorm = pendingNorm
                    }
                    continue
                }
                lastHash = hash
                idle = 0

                val text = try {
                    recognize(crop)
                } finally {
                    crop.recycle()
                }

                val norm = text.lowercase().filter { it.isLetterOrDigit() }
                if (norm.length < 2) {
                    empty++
                    if (empty >= 2) { // اختفى الحوار
                        pendingNorm = ""; pendingText = ""; shownNorm = ""; unstable = 0
                    }
                    continue
                }
                empty = 0

                // ننتظر حتى يستقر النص (الألعاب تكتب الحوار حرفًا حرفًا)
                if (norm != pendingNorm) {
                    pendingNorm = norm
                    pendingText = text
                    unstable++
                    if (unstable < MAX_UNSTABLE_READS) continue
                }
                unstable = 0
                pendingText = text
                if (norm == shownNorm) continue
                if (translateAndShow(text)) shownNorm = norm
            }
        }
    }

    // ----------------------------------------------------------- الواجهة العائمة

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** يضيف نافذة عائمة بأمان (قد يفشل إن سُحب الإذن). */
    private fun safeAdd(v: View, lp: WindowManager.LayoutParams): Boolean {
        return try {
            wm.addView(v, lp)
            true
        } catch (e: Exception) {
            toast("تعذّر عرض النافذة العائمة. تأكد من إذن العرض فوق التطبيقات.")
            false
        }
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "🌐"
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1565C0.toInt())
            }
            setOnClickListener { showSelection() }
            setOnLongClickListener { stopSelf(); true }
        }
        val lp = WindowManager.LayoutParams(
            dp(52), dp(52), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(120)
        }
        if (safeAdd(b, lp)) {
            bubble = b
        } else {
            stopSelf()
        }
    }

    private fun showSelection() {
        removeView(selectionView); selectionView = null
        try { rebuildCapture() } catch (_: Exception) { } // مطابقة اتجاه الشاشة الحالي
        val v = SelectionView(this) { rect ->
            region = rect
            saveRegion(rect)
            resetTextState()
            removeView(selectionView); selectionView = null
            showBar(rect)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (safeAdd(v, lp)) selectionView = v
    }

    /** يطبّق إعدادات المستخدم (حجم الخط، اللون، الشفافية) على جملة مترجمة. */
    private fun applyStyle(tv: TextView) {
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.fontSp(this).toFloat())
        tv.setTextColor(Prefs.textColor(this))
        tv.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        val alpha = Prefs.bgOpacity(this) * 255 / 100
        (tv.background as? GradientDrawable)?.setColor(Color.argb(alpha, 0, 0, 0))
    }

    private fun restyleBar() {
        val box = bar ?: return
        for (c in captions) applyStyle(c)
        val r = region ?: return
        try {
            wm.updateViewLayout(box, barLayoutParams(r))
        } catch (_: Exception) { }
    }

    /** تقدير ارتفاع الشريط (3 أسطر) لاستخدامه في تفادي التداخل مع منطقة الحوار. */
    private fun estimateBarHeight(): Int {
        val px = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, Prefs.fontSp(this).toFloat(), resources.displayMetrics
        )
        return (px * 1.4f * 3).toInt() + dp(16)
    }

    private fun baseBarParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun barLayoutParams(r: Rect): WindowManager.LayoutParams {
        // مكان حرّكه المستخدم بيده له الأولوية
        val custom = loadBarPos()
        if (custom != null) {
            return baseBarParams().apply {
                gravity = Gravity.TOP or Gravity.START
                x = custom.first.coerceIn(0, maxOf(0, capW - dp(40)))
                y = custom.second.coerceIn(0, maxOf(0, capH - dp(40)))
            }
        }

        val est = estimateBarHeight()
        val gap = dp(8)
        val margin = dp(24)
        var pos = Prefs.position(this)

        fun overlaps(top: Int, bottom: Int) = top < r.bottom && bottom > r.top

        // إذا تداخل المكان المختار مع منطقة الحوار (فتقرأ الشاشة الترجمة نفسها)، انقله
        when (pos) {
            Prefs.POS_TOP -> if (overlaps(margin, margin + est)) pos = Prefs.POS_ABOVE
            Prefs.POS_MIDDLE -> {
                val t = capH / 2 - est / 2
                if (overlaps(t, t + est)) pos = Prefs.POS_ABOVE
            }
            Prefs.POS_BOTTOM -> {
                if (overlaps(capH - margin - est, capH - margin)) pos = Prefs.POS_ABOVE
            }
        }
        if (pos == Prefs.POS_ABOVE && r.top < est + gap) pos = Prefs.POS_BELOW
        if (pos == Prefs.POS_BELOW && r.bottom + est + gap > capH && r.top >= est + gap) {
            pos = Prefs.POS_ABOVE
        }

        return baseBarParams().apply {
            when (pos) {
                Prefs.POS_ABOVE -> {
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    y = capH - r.top + gap
                }
                Prefs.POS_BELOW -> {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = r.bottom + gap
                }
                Prefs.POS_TOP -> {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = margin
                }
                Prefs.POS_MIDDLE -> {
                    gravity = Gravity.CENTER
                    y = 0
                }
                else -> {
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    y = margin
                }
            }
        }
    }

    /** حاوية الترجمات: شفافة، وكل جملة داخلها لها خلفيتها الخاصة بقدر نصها فقط. */
    private fun showBar(r: Rect) {
        removeView(bar)
        captions.clear()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            visibility = View.GONE
        }
        attachDrag(box)
        if (safeAdd(box, barLayoutParams(r))) {
            bar = box
        } else {
            bar = null
        }
    }

    /** ضغطة طويلة على الشريط ثم سحب لتحريكه؛ المكان الجديد يُحفظ لكل لعبة واتجاه. */
    private fun attachDrag(box: View) {
        var dragging = false
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                val lp = box.layoutParams as? WindowManager.LayoutParams ?: return
                val loc = IntArray(2)
                box.getLocationOnScreen(loc)
                lp.gravity = Gravity.TOP or Gravity.START
                lp.x = loc[0]
                lp.y = loc[1]
                startX = lp.x
                startY = lp.y
                dragging = true
                box.alpha = 0.7f
                try { wm.updateViewLayout(box, lp) } catch (_: Exception) { }
            }
        })

        box.setOnTouchListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                downX = ev.rawX
                downY = ev.rawY
            }
            detector.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> if (dragging) {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    lp.x = startX + (ev.rawX - downX).toInt()
                    lp.y = startY + (ev.rawY - downY).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) { }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                    dragging = false
                    v.alpha = 1f
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    saveBarPos(lp.x, lp.y)
                }
            }
            true
        }
    }

    /** يضيف جملة مترجمة أسفل الجمل الظاهرة، وتختفي بعد المدة المحددة في الإعدادات. */
    private fun addCaption(translated: String, original: String) {
        val box = bar ?: return
        val tv = TextView(this).apply {
            text = if (Prefs.showOriginal(this@TranslateService)) {
                "$translated\n$original"
            } else {
                translated
            }
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            maxWidth = (capW * 0.8f).toInt()
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat() }
        }
        applyStyle(tv)
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(4)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        box.addView(tv, lp)
        captions.add(tv)
        while (captions.size > MAX_CAPTIONS) removeCaption(captions[0])
        box.visibility = View.VISIBLE
        main.postDelayed({ removeCaption(tv) }, Prefs.durationMs(this).toLong())
    }

    private fun removeCaption(tv: TextView) {
        if (!captions.remove(tv)) return
        val box = bar ?: return
        box.removeView(tv)
        if (captions.isEmpty()) box.visibility = View.GONE
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) { }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    // ------------------------------------------------------------------ إنهاء

    override fun onDestroy() {
        if (::wm.isInitialized) {
            Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        }
        loopJob?.cancel()
        watcherJob?.cancel()
        scope.cancel()
        main.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) {
            removeView(selectionView)
            removeView(bubble)
            removeView(bar)
        }
        virtualDisplay?.release()
        imageReader?.close()
        // نلغي تسجيل callback أولًا حتى لا يستدعي stop() الدالة onStop من جديد
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}
