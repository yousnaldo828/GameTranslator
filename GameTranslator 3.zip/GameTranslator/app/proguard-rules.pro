# قواعد R8 لنسخة release.
# مكتبات ML Kit تأتي مع قواعدها الخاصة (consumer rules)، فلا نحتاج إلى قواعد keep إضافية.
# إذا ظهرت تحذيرات عند بناء release يمكن إضافة dontwarn هنا حسب الحاجة.
-dontwarn com.google.mlkit.**
