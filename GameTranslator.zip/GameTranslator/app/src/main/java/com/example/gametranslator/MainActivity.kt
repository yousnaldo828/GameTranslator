package com.example.gametranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var startButton: Button

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // نكمل حتى لو رفض المستخدم الإشعارات
            prepareModelThenCapture()
        }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val intent = Intent(this, TranslateService::class.java).apply {
                    putExtra(TranslateService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(TranslateService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(
                    this,
                    "افتح اللعبة ثم اضغط على زر 🌐 لتحديد منطقة الحوار",
                    Toast.LENGTH_LONG
                ).show()
                moveTaskToBack(true)
            } else {
                setStatus("لم يتم منح إذن التقاط الشاشة.")
            }
            startButton.isEnabled = true
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "مترجم الألعاب\nإنجليزي ← عربي"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "اضغط «ابدأ» ثم افتح اللعبة.\nبعدها اضغط على زر 🌐 العائم وحدد المنطقة التي يظهر فيها الحوار."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        startButton = Button(this).apply {
            text = "ابدأ"
            setOnClickListener { onStartClicked() }
        }
        val stopButton = Button(this).apply {
            text = "إيقاف الخدمة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TranslateService::class.java))
                setStatus("تم الإيقاف.")
            }
        }

        root.addView(title)
        root.addView(status)
        root.addView(startButton)
        root.addView(stopButton)
        setContentView(root)
    }

    private fun onStartClicked() {
        // 1) إذن الرسم فوق التطبيقات
        if (!Settings.canDrawOverlays(this)) {
            setStatus("فعّل إذن «العرض فوق التطبيقات الأخرى» ثم ارجع واضغط «ابدأ» مرة أخرى.")
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        // 2) إذن الإشعارات (أندرويد 13+)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        prepareModelThenCapture()
    }

    private fun prepareModelThenCapture() {
        startButton.isEnabled = false
        setStatus("جارٍ تحميل نموذج الترجمة (مرة واحدة فقط، يحتاج إنترنت)...")
        lifecycleScope.launch {
            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build()
            )
            try {
                translator.downloadModelIfNeeded().await()
                setStatus("النموذج جاهز. وافق على التقاط الشاشة.")
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                captureLauncher.launch(mpm.createScreenCaptureIntent())
            } catch (e: Exception) {
                setStatus("فشل تحميل النموذج. تأكد من الاتصال بالإنترنت وحاول مجددًا.")
                startButton.isEnabled = true
            } finally {
                translator.close()
            }
        }
    }

    private fun setStatus(text: String) {
        status.text = text
    }
}
