package com.example.gametranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View

/**
 * طبقة شفافة تغطي الشاشة: يسحب المستخدم مستطيلًا حول المنطقة التي يظهر فيها الحوار.
 * الإحداثيات المُرجعة هي إحداثيات الشاشة الحقيقية (بالبكسل).
 */
class SelectionView(
    context: Context,
    private val onSelected: (Rect) -> Unit
) : View(context) {

    private val dimPaint = Paint().apply { color = 0x99000000.toInt() }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.CYAN
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 46f
        textAlign = Paint.Align.CENTER
    }

    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var dragging = false
    private val loc = IntArray(2)

    override fun onDraw(canvas: Canvas) {
        getLocationOnScreen(loc)
        if (!dragging) {
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
            canvas.drawText(
                "اسحب لتحديد المنطقة التي يظهر فيها الحوار",
                width / 2f, height / 2f, hintPaint
            )
            return
        }
        val l = minOf(startX, endX) - loc[0]
        val r = maxOf(startX, endX) - loc[0]
        val t = minOf(startY, endY) - loc[1]
        val b = maxOf(startY, endY) - loc[1]
        val w = width.toFloat()
        val h = height.toFloat()
        // تعتيم كل ما حول المستطيل
        canvas.drawRect(0f, 0f, w, t, dimPaint)
        canvas.drawRect(0f, b, w, h, dimPaint)
        canvas.drawRect(0f, t, l, b, dimPaint)
        canvas.drawRect(r, t, w, b, dimPaint)
        canvas.drawRect(l, t, r, b, borderPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.rawX; startY = event.rawY
                endX = startX; endY = startY
                dragging = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                endX = event.rawX; endY = event.rawY
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                endX = event.rawX; endY = event.rawY
                dragging = false
                val rect = Rect(
                    minOf(startX, endX).toInt(),
                    minOf(startY, endY).toInt(),
                    maxOf(startX, endX).toInt(),
                    maxOf(startY, endY).toInt()
                )
                if (rect.width() > 100 && rect.height() > 40) {
                    onSelected(rect)
                } else {
                    invalidate() // مستطيل صغير جدًا: حاول مرة أخرى
                }
            }
        }
        return true
    }
}
