package com.example.gametranslator

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** شاشة اختيار التطبيقات (الألعاب) التي تعمل فيها الترجمة. */
class AppPickerActivity : AppCompatActivity() {

    private class AppItem(val label: String, val pkg: String, val info: ResolveInfo)

    private val all = ArrayList<AppItem>()
    private val shown = ArrayList<AppItem>()
    private val selected = HashSet<String>()
    private lateinit var adapter: Adapter
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected.addAll(Prefs.apps(this))

        val pad = dp(12)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        info = TextView(this).apply {
            textSize = 14f
            text = "جارٍ تحميل التطبيقات..."
            setPadding(0, 0, 0, dp(8))
        }
        val search = EditText(this).apply {
            hint = "بحث عن تطبيق"
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    filter(s?.toString() ?: "")
                }
            })
        }
        adapter = Adapter()
        val list = ListView(this).apply {
            this.adapter = this@AppPickerActivity.adapter
            setOnItemClickListener { _, _, position, _ ->
                val item = shown[position]
                if (!selected.add(item.pkg)) selected.remove(item.pkg)
                Prefs.setApps(this@AppPickerActivity, selected)
                updateInfo()
                this@AppPickerActivity.adapter.notifyDataSetChanged()
            }
        }
        root.addView(info)
        root.addView(search)
        root.addView(
            list,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        lifecycleScope.launch {
            val items = withContext(Dispatchers.Default) { loadApps() }
            all.clear()
            all.addAll(items)
            filter("")
            updateInfo()
        }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it) }
            .sortedWith(
                compareBy<AppItem> { it.pkg !in selected }.thenBy { it.label.lowercase() }
            )
    }

    private fun filter(q: String) {
        val query = q.trim().lowercase()
        shown.clear()
        shown.addAll(
            if (query.isEmpty()) all
            else all.filter { it.label.lowercase().contains(query) || it.pkg.contains(query) }
        )
        adapter.notifyDataSetChanged()
    }

    private fun updateInfo() {
        info.text = if (selected.isEmpty()) {
            "لم تختر شيئًا: الترجمة ستعمل في كل التطبيقات.\nاضغط على تطبيق لاختياره (الألعاب مثلًا)."
        } else {
            "المختارة: ${selected.size} تطبيق. الترجمة تظهر فيها فقط."
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class Holder(val icon: ImageView, val name: TextView, val check: CheckBox)

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: View
            val h: Holder
            if (convertView == null) {
                val icon = ImageView(this@AppPickerActivity)
                val name = TextView(this@AppPickerActivity).apply {
                    textSize = 16f
                    gravity = Gravity.CENTER_VERTICAL
                }
                val check = CheckBox(this@AppPickerActivity).apply {
                    isClickable = false
                    isFocusable = false
                }
                val layout = LinearLayout(this@AppPickerActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(4), dp(8), dp(4), dp(8))
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                }
                layout.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                layout.addView(
                    name,
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        setMargins(dp(12), 0, dp(12), 0)
                    }
                )
                layout.addView(check)
                h = Holder(icon, name, check)
                layout.tag = h
                row = layout
            } else {
                row = convertView
                h = row.tag as Holder
            }
            val item = shown[position]
            h.name.text = item.label
            h.icon.setImageDrawable(item.info.loadIcon(packageManager))
            h.check.isChecked = item.pkg in selected
            return row
        }
    }
}
