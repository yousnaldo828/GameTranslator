package com.example.gametranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * الخدمة الأمامية التي تقوم بالعمل كله:
 * التقاط الشاشة -> قص منطقة الحوار -> OCR -> ترجمة -> عرض الترجمة فوق اللعبة.
 * وتعمل فقط داخل التطبيقات التي اختارها المستخدم (أو في الكل إن لم يختر شيئًا).
 */
class TranslateService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val ACTION_STOP = "com.example.gametranslator.STOP"
        private const val CHANNEL_ID = "translator"
        private const val NOTIF_ID = 1
        private const val WATCH_DELAY_MS = 700L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var capW = 0
    private var capH = 0

    private var region: Rect? = null
    private var selectionView: SelectionView? = null
    private var bubble: TextView? = null
    private var bar: TextView? = null
    private var loopJob: Job? = null
    private var watcherJob: Job? = null

    private var lastText = ""
    private var emptyReads = 0
    private val cache = HashMap<String, String>()

    // مراقبة التطبيق المفتوح
    @Volatile private var allowed = true
    @Volatile private var contextPkg: String? = null
    private var lastForeground: String? = null
    private var lastEventTs = 0L

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )

    // يجب الاحتفاظ بمرجع قوي للمستمع وإلا يُحذف تلقائيًا
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == null || !key.startsWith("region_")) {
            main.post { restyleBar() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY // الخدمة تعمل بالفعل

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(resultCode, data)
        // أندرويد 14 يشترط تسجيل callback قبل إنشاء VirtualDisplay
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, main)

        rebuildCapture()
        showBubble()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefsListener)

        // تحميل النموذج (يكون جاهزًا غالبًا من الشاشة الرئيسية)
        scope.launch {
            try {
                translator.downloadModelIfNeeded().await()
            } catch (e: Exception) {
                toast("تعذّر تحميل نموذج الترجمة")
            }
        }
        startWatcher()
        startLoop()
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- إشعار

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "مترجم الألعاب", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification = builder
            .setContentTitle("مترجم الألعاب يعمل")
            .setContentText("اضغط على زر 🌐 فوق اللعبة لتحديد منطقة الحوار")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(Notification.Action.Builder(null, "إيقاف", stopIntent).build())
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    // ---------------------------------------------------------- التقاط الشاشة

    private fun screenSize(): Triple<Int, Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.configuration.densityDpi)
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }
    }

    /** ينشئ (أو يعيد ضبط) قارئ الصور ليطابق اتجاه الشاشة الحالي (عمودي/أفقي). */
    private fun rebuildCapture() {
        val (w, h, dpi) = screenSize()
        val old = imageReader
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = virtualDisplay
        if (vd == null) {
            virtualDisplay = projection?.createVirtualDisplay(
                "GameTranslatorCapture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = reader.surface
        }
        imageReader = reader
        old?.close()
        capW = w
        capH = h
    }

    /** يلتقط آخر إطار ويعيد المنطقة المحددة فقط كصورة. */
    private fun grabCrop(r: Rect): Bitmap? {
        val image = imageReader?.acquireLatestImage() ?: return null
        try {
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * image.width
            val full = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(plane.buffer)

            val x = r.left.coerceIn(0, image.width - 2)
            val y = r.top.coerceIn(0, image.height - 2)
            val w = r.width().coerceAtMost(image.width - x).coerceAtLeast(1)
            val h = r.height().coerceAtMost(image.height - y).coerceAtLeast(1)
            val crop = Bitmap.createBitmap(full, x, y, w, h)
            full.recycle()
            return crop
        } finally {
            image.close()
        }
    }

    // ------------------------------------------- مراقبة التطبيق المفتوح حاليًا

    private fun updateForeground() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastEventTs == 0L) now - 2 * 3600 * 1000L else lastEventTs
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            lastEventTs = maxOf(lastEventTs, e.timeStamp + 1)
            val pkg = e.packageName ?: continue
            if (pkg == "com.android.systemui") continue
            @Suppress("DEPRECATION")
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> lastForeground = pkg
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (lastForeground == pkg) lastForeground = null
            }
        }
    }

    private fun startWatcher() {
        watcherJob = scope.launch {
            while (isActive) {
                val selected = Prefs.apps(this@TranslateService)
                val usage = Prefs.hasUsageAccess(this@TranslateService)
                if (usage) {
                    try { updateForeground() } catch (_: Exception) { }
                }
                val pkgNow = if (usage) lastForeground else null
                val newAllowed = selected.isEmpty() || !usage ||
                    (pkgNow != null && pkgNow in selected)

                if (newAllowed != allowed || pkgNow != contextPkg) {
                    allowed = newAllowed
                    contextPkg = pkgNow
                    withContext(Dispatchers.Main) { onContextChanged() }
                }
                delay(WATCH_DELAY_MS)
            }
        }
    }

    /** يُستدعى (في الخيط الرئيسي) عند تغيّر التطبيق المفتوح أو السماح بالعمل. */
    private fun onContextChanged() {
        lastText = ""
        emptyReads = 0
        removeView(bar); bar = null
        if (!allowed) {
            removeView(selectionView); selectionView = null
            bubble?.visibility = View.GONE
            region = null
            return
        }
        bubble?.visibility = View.VISIBLE
        region = loadRegion()
        region?.let { showBar(it) }
    }

    // ------------------------------------------- حفظ منطقة الحوار لكل لعبة واتجاه

    private fun regionKey() = "region_${contextPkg ?: "global"}_${capW}x$capH"

    private fun saveRegion(r: Rect) {
        Prefs.sp(this).edit()
            .putString(regionKey(), "${r.left},${r.top},${r.right},${r.bottom}")
            .apply()
    }

    private fun loadRegion(): Rect? {
        val s = Prefs.sp(this).getString(regionKey(), null) ?: return null
        val p = s.split(",")
        if (p.size != 4) return null
        return try {
            Rect(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt())
        } catch (e: NumberFormatException) {
            null
        }
    }

    // ---------------------------------------------------------- حلقة الترجمة

    private fun startLoop() {
        loopJob = scope.launch {
            while (isActive) {
                delay(Prefs.intervalMs(this@TranslateService).toLong())
                if (!allowed) continue

                // تغيّر اتجاه الشاشة: أعد الضبط، وإن لم توجد منطقة محفوظة اطلب تحديدًا جديدًا
                val (w, h, _) = screenSize()
                if (w != capW || h != capH) {
                    withContext(Dispatchers.Main) {
                        rebuildCapture()
                        onContextChanged()
                        if (allowed && region == null) showSelection()
                    }
                    continue
                }

                val r = region ?: continue
                val crop = grabCrop(r) ?: continue

                val text = try {
                    val result = recognizer.process(InputImage.fromBitmap(crop, 0)).await()
                    result.text.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
                } catch (e: Exception) {
                    ""
                } finally {
                    crop.recycle()
                }

                if (text.length < 2) {
                    emptyReads++
                    if (emptyReads >= 4) { // اختفى الحوار: أخفِ الشريط
                        lastText = ""
                        withContext(Dispatchers.Main) { bar?.visibility = View.GONE }
                    }
                    continue
                }
                emptyReads = 0
                if (text == lastText) continue
                lastText = text

                val translated = cache[text] ?: try {
                    translator.translate(text).await().also { cache[text] = it }
                } catch (e: Exception) {
                    continue
                }

                withContext(Dispatchers.Main) {
                    bar?.apply {
                        this.text = translated
                        visibility = View.VISIBLE
                    }
                }
            }
        }
    }

    // ----------------------------------------------------------- الواجهة العائمة

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "🌐"
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1565C0.toInt())
            }
            setOnClickListener { showSelection() }
            setOnLongClickListener { stopSelf(); true }
        }
        val lp = WindowManager.LayoutParams(
            dp(52), dp(52), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(120)
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun showSelection() {
        removeView(selectionView); selectionView = null
        rebuildCapture() // التأكد من مطابقة اتجاه الشاشة الحالي
        val v = SelectionView(this) { rect ->
            region = rect
            saveRegion(rect)
            lastText = ""
            emptyReads = 0
            removeView(selectionView); selectionView = null
            showBar(rect)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        selectionView = v
    }

    /** يطبّق إعدادات المستخدم (حجم الخط، اللون، الشفافية) على شريط الترجمة. */
    private fun applyStyle(tv: TextView) {
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.fontSp(this).toFloat())
        tv.setTextColor(Prefs.textColor(this))
        tv.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        val alpha = Prefs.bgOpacity(this) * 255 / 100
        (tv.background as? GradientDrawable)?.setColor(Color.argb(alpha, 0, 0, 0))
    }

    private fun restyleBar() {
        val tv = bar ?: return
        applyStyle(tv)
        val r = region ?: return
        try {
            wm.updateViewLayout(tv, barLayoutParams(r))
        } catch (_: Exception) { }
    }

    /** تقدير ارتفاع الشريط (3 أسطر) لاستخدامه في تفادي التداخل مع منطقة الحوار. */
    private fun estimateBarHeight(): Int {
        val px = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, Prefs.fontSp(this).toFloat(), resources.displayMetrics
        )
        return (px * 1.4f * 3).toInt() + dp(16)
    }

    private fun barLayoutParams(r: Rect): WindowManager.LayoutParams {
        val est = estimateBarHeight()
        val gap = dp(8)
        val margin = dp(24)
        var pos = Prefs.position(this)

        fun overlaps(top: Int, bottom: Int) = top < r.bottom && bottom > r.top

        // إذا تداخل المكان المختار مع منطقة الحوار (فتقرأ الشاشة الترجمة نفسها)، انقله
        when (pos) {
            Prefs.POS_TOP -> if (overlaps(margin, margin + est)) pos = Prefs.POS_ABOVE
            Prefs.POS_MIDDLE -> {
                val t = capH / 2 - est / 2
                if (overlaps(t, t + est)) pos = Prefs.POS_ABOVE
            }
            Prefs.POS_BOTTOM -> {
                if (overlaps(capH - margin - est, capH - margin)) pos = Prefs.POS_ABOVE
            }
        }
        if (pos == Prefs.POS_ABOVE && r.top < est + gap) pos = Prefs.POS_BELOW
        if (pos == Prefs.POS_BELOW && r.bottom + est + gap > capH && r.top >= est + gap) {
            pos = Prefs.POS_ABOVE
        }

        return WindowManager.LayoutParams(
            (capW * 0.8f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            when (pos) {
                Prefs.POS_ABOVE -> {
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    y = capH - r.top + gap
                }
                Prefs.POS_BELOW -> {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = r.bottom + gap
                }
                Prefs.POS_TOP -> {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = margin
                }
                Prefs.POS_MIDDLE -> {
                    gravity = Gravity.CENTER
                    y = 0
                }
                else -> {
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    y = margin
                }
            }
        }
    }

    /** شريط الترجمة: يوضع حسب إعدادات المستخدم دون أن يغطي منطقة الحوار. */
    private fun showBar(r: Rect) {
        removeView(bar)
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat() }
            visibility = View.GONE
        }
        applyStyle(tv)
        wm.addView(tv, barLayoutParams(r))
        bar = tv
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) { }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    // ------------------------------------------------------------------ إنهاء

    override fun onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        loopJob?.cancel()
        watcherJob?.cancel()
        scope.cancel()
        removeView(selectionView)
        removeView(bubble)
        removeView(bar)
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}
